import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.File;

public class Main {

    /**
     * Main method of the project.  Asks the user to start new or to load in a previous session saved on a file.
     * @param args
     */
    public static void main(String[] args) {

        int choice = 0;
        boolean valid = false;
        greeting();

        do {

            try {
                Scanner scan = new Scanner(System.in);
                choice = scan.nextInt();

                switch (choice){
                    case 1:
                        Game playNew = new Game();
                        playNew.gameStart();
                        valid = true;
                        break;
                    case 2:
                        loadGame();
                        valid = true;
                        break;
                    case 3:
                        quit();
                        valid = true;
                        break;
                    default:
                        System.out.println("Sorry, you must pick 1-3.");
                }
            } catch (InputMismatchException e) {

                System.out.println("Sorry, that is not an option.  Use the numbers to the left ");
                valid = false;
                greeting();
            }

        } while (valid == false);
    }


    /**
     * Loads data from the saveGame.txt document and loads info into variables.
     */
    public static void loadGame(){

        File file = new File("savedGame.txt");

        try {
            Scanner reader = new Scanner(file);
            int value1 = reader.nextInt();
            int value2 = reader.nextInt();
            int playerNum = reader.nextInt();
            int turnPoints = reader.nextInt();

            reader.close();

            Game playLoad = new Game(value1, value2, playerNum, turnPoints);
            playLoad.gameStart();

        }catch(FileNotFoundException ex){

            System.out.printf("Error: %s\n", ex);
        }
    }

    /**
     * Simple greeting by display of options.
     */
    public static void greeting() {


        System.out.println("1) New Game");
        System.out.println("2) Load Game");
        System.out.println("3) Quit");


    }

    /**
     * Prints out a goodbye message when the player quits.
     */
    public static void quit(){

        System.out.println("See you next time!");
    }
}
