public class Player {

    private int score;
    private String name;

    /**
     * Constructor of the Player class.  Sets the initial score to 0.
     */
    public Player(String name){

        this.name = name;
        score = 0;
    }

    /**
     * Simply returns the name of the player.
     * @return
     */
    public String getName(){

        return name;
    }

    /**
     * Returns the value of the player's score.
     * @return
     */
    public int getScore(){

        return score;
    }

    /**
     * Sets the score for the player.  It may either be increased by dice roll or changed by
     * importing the saved game score.
     * @param value
     */
    public void setScore(int value){

        score += value;
    }
}
