import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.File;

public class Game {

    private Dice die;
    private Player player1;
    private Player player2;
    private Player currentPlayer;
    private int turnTotal;
    private int playerNum;
    private static final int WIN = 100;

    /**
     * Constructor for the Game class.  This is used when a new game is created.  It instantiates 2 player objects and a current
     * player object ot keep track of turns.  It also instantiates a die.
     */
    public Game(){

        die = new Dice();
        player1 = new Player("Golden Monkeys");
        player2 = new Player("Silver Owls");
        currentPlayer = player1;
        turnTotal = 0;
        playerNum = 1;
    }

    /**
     * Constructor for the Game class.  This is used when a game is loaded from a file.  It initializes the player's scores to
     * what they were in the previous session and sets the current player to what it was before the last game ended.
     * @param value1
     * @param value2
     * @param playerNum
     */
    public Game(int value1, int value2, int playerNum, int turnTotal){

        die = new Dice();

        player1 = new Player("Golden Monkeys");
        player1.setScore(value1);

        player2 = new Player("Silver Owls");
        player2.setScore(value2);

        if(playerNum == 1){

            this.currentPlayer = player1;
        }
        else{
            this.currentPlayer = player2;
        }
        this.turnTotal = turnTotal;
    }

    /**
     * Startst the game.  Player may choose 1, 2, 3, or 4.  They may roll, hold, quit without saving, or quit with saving.
     */
    public void gameStart(){

        int choice = 0;
        boolean valid = false;
        boolean gameOver = false;

        do {

            showOptions();
            displayInfo();
            try{

                Scanner scan = new Scanner(System.in);
                choice = scan.nextInt();

                switch (choice){

                    case 1:
                        rollDie();
                        valid = false;
                        break;
                    case 2:
                        valid = false;
                        hold();
                        gameOver = checkWin();
                        if(gameOver == true){

                            valid = true;
                        }
                        break;
                    case 3:
                        saveGame();
                        System.out.println("Saved! Bye!");
                        valid = true;
                        break;
                    case 4:
                        System.out.println("See ya!");
                        valid = true;
                        break;
                    default:
                        System.out.println("Sorry, you need to input a valid number.");
                        valid = false;
                }

            }catch (InputMismatchException e){

                System.out.println("Sorry, you must choose a number from the option list.");

            }
        }while(valid == false);
    }


    /**
     * Saves data from the game into the savedGame.txt file.  If it doesn't exist, it makes it.
     */
    public void saveGame(){

        File file = new File("savedGame.txt");
        try{
            PrintWriter output = new PrintWriter(file);
            output.println(player1.getScore());
            output.println(player2.getScore());
            output.println(playerNum);
            output.println(turnTotal);
            output.close();

        }catch(IOException ex){
            System.out.printf("Error: %s\n", ex);
        }
    }

    /**
     * Shows the user the current player, player score, and turn total.
     */
    public void displayInfo(){

        System.out.println("Player: " + currentPlayer.getName());
        System.out.println("Score: " + currentPlayer.getScore());
        System.out.println("Round total: " + turnTotal);
    }

    /**
     * Sets the turn total to 0 and sets the current player to a new player.
     */
    public void switchPlayer(){

        if(currentPlayer == player1){

            currentPlayer = player2;
            playerNum = 2;
        }
        else{

            currentPlayer = player1;
            playerNum = 1;
        }

        System.out.println("*****************************************");
        System.out.println("Players switch!");
        System.out.println("*****************************************");
        turnTotal = 0;
    }

    /**
     * Checks to see if the current player won.  If they do, the game over signal is given and the game ends.
     * If they don't, the player turns are switched.
     * @return
     */
    public boolean checkWin(){

        boolean gameOver = false;

        if(currentPlayer.getScore() >= WIN){

            gameOver = true;

            if(currentPlayer == player1){

                System.out.println("The Golden Monkeys Win!");
            }
            else{

                System.out.println("The Silver Owls Win!");
            }
        }
        else {
            switchPlayer();
        }

        return gameOver;
    }

    /**
     * Adds the turn total to the player's score.
     */
    public void hold(){

        currentPlayer.setScore(turnTotal);

    }

    /**
     * Rolls a die, then gets the value of the die roll.  If the value equals anything other than 1, the number is added
     * to the turnTotal field.  If the roll is a one, it resets the turn total field and switches players.
     */
    public void rollDie(){

        die.setValue();
        int rollNum = die.getValue();

        if(rollNum > 1 && rollNum <= die.getMaxSides()){

            turnTotal += rollNum;
        }
        else if(rollNum == 1){

            turnTotal = 0;
            switchPlayer();
        }
    }

    /**
     * Shows the options to the player.
     */
    public void showOptions(){

        System.out.println("1) Roll Die");
        System.out.println("2) Hold");
        System.out.println("3) Save and Quit");
        System.out.println("4) Quit Without Saving");
    }
}
