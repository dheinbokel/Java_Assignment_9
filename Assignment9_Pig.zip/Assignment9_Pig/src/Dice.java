import java.util.Random;

public class Dice {

    private int value;
    private static final int MAX_SIDES = 6;
    private Random newRand;

    /**
     * Constructor for the Dice class.  Initializes value and newRand.
     */
    public Dice(){

        value = 0;
        newRand = new Random();
    }

    /**
     * Returns the value of the variable "value".
     * @return
     */
    public int getValue(){

        return value;
    }

    /**
     * Sets the value of the dice to the random die roll then it displays the value of the die.
     */
    public void setValue(){

        value = newRand.nextInt(MAX_SIDES)+1;
        System.out.println("*****************************************");
        System.out.println("You rolled a " + value + "!");
        System.out.println("*****************************************");
    }

    /**
     * Returns the value of MAX_SIDES.
     * @return
     */
    public int getMaxSides(){

        return MAX_SIDES;
    }
}
